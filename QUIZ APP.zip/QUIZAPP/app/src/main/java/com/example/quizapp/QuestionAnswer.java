package com.example.quizapp;

public class QuestionAnswer {

    // Array of questions
    public static String[] question = {
            "What is the capital of France?",
            "What is 2 + 2?",
            "What is the largest planet in our solar system?"
    };

    // Array of choices for each question
    public static String[][] choices = {
            {"Paris", "London", "Berlin", "Madrid"},
            {"3", "4", "5", "6"},
            {"Earth", "Jupiter", "Mars", "Saturn"}
    };

    // Array of correct answers for each question
    public static String[] correctAnswers = {
            "Paris",
            "4",
            "Jupiter"
    };
}

